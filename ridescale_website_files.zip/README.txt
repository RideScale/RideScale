RideScale Website Files

Upload these two files to your GitHub repository:
1. index.html
2. style.css

Important:
- Both files must be in the main/root area of the repository.
- Do not upload the folder itself.
- Replace the old index.html that says "Hi there".
- After uploading, click Commit changes.
- Wait about 1 minute, then refresh your live site.
